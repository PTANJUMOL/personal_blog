from django import forms
from .models import Profile, Post, Category, Comments, Work, Education
from adminpanel.models import Category as cat
from ckeditor.widgets import CKEditorWidget
# from .forms import CoverPhotoForm

# class ProfileForm(forms.ModelForm):
#     class Meta:
#         model = Profile
#         fields = '__all__'

class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = '__all__'

# class PostForm(forms.ModelForm):
#     class Meta:
#         model = Post
#         fields = '__all__'

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comments
        fields = '__all__'

class WorkForm(forms.ModelForm):
    class Meta:
        model = Work
        fields = '__all__'

class EducationForm(forms.ModelForm):
    class Meta:
        model = Education
        fields = '__all__'

class CoverPhotoForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['profile_coverphoto']  # or whatever fields you have

class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = [
            'profile_name',
            'profile_photo',
            'profile_coverphoto',
            'profile_blogid',
            'profile_about',
            'profile_gender',
            'profile_dob',
            'profile_work',
            'profile_education',
            'profile_phone',
            'profile_email',
        ]
        widgets = {
            'profile_dob': forms.DateInput(attrs={'type': 'date'})
        }

# class PostForm(forms.ModelForm):
#     post_category = forms.ModelChoiceField(
#         queryset=Category.objects.all(),
#         empty_label="-- Select Category --"
#     )

#     class Meta:
#         model = Post
#         fields = ['post_title', 'post_data', 'post_category', 'post_status']



class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        exclude = ['post_likes', 'post_created_by', 'post_created_date', 'post_published_date']
        fields = ['post_title', 'post_data', 'post_category', 'post_status', 'post_main_image']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['post_category'].queryset = cat.objects.all()
        self.fields['post_category'].empty_label = "-- Select Category --"

    post_data = forms.CharField(widget=CKEditorWidget())
