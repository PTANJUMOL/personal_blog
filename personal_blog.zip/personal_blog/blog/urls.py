from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('post/', views.single_post, name='single'),
    # path('update-cover-photo/', views.update_cover_photo, name='update_cover_photo'),
    path('update-coverphoto/', views.update_coverphoto, name='update_coverphoto'),
    path('update_profile/', views.update_profile, name='update_profile'),
     path('create_post/', views.create_post, name='create_post'), 
     path('post/<int:id>/', views.single_post, name='single'),
    #  path('like/', views.like_post, name='like_post'),
     path('like/<int:post_id>/', views.like_post, name='like_post'),
     path("follow_list/", views.follow_list, name="follow_list"),
    #  path("author_list/", views.follow_list, name="author_list"),
     path('follow/<int:profile_id>/', views.follow_author, name='follow_author'),
     path("my-posts/", views.my_posts, name="my_posts"),
     path("following/", views.following_posts, name="following_posts"),
     path('most-liked/', views.most_liked_posts, name='most_liked'),
     path('posts/category/<int:category_id>/', views.posts_by_category, name='posts_by_category'),
     path("comments/<int:post_id>/", views.get_comments, name="get_comments"),
     path("comments/add/<int:post_id>/", views.add_comment, name="add_comment"),

    path('', views.home, name='home'),
    
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)