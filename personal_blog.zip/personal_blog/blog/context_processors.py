from .models import Post
from .models import cat

def recent_posts(request):
    posts = Post.objects.filter(post_status="published").order_by('-post_published_date')[:4]
    return {'recent_posts': posts}
def categories_processor(request):
    return {'categories': cat.objects.all()}