from django.shortcuts import render, get_object_or_404, redirect
# from .forms import CoverPhotoForm
from django.db.models import Count
from .models import Profile,Follow
from .models import Post, PostLike,Comments
from .forms import ProfileForm
from .forms import PostForm
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from adminpanel.models import Category as cat
import json
from django.db.models import Exists, OuterRef,BooleanField

# Create your views here.
# def home(request):
#     return render(request, 'blog/index.html')

# def home(request):
#     # Show only published posts, latest first
#     posts = Post.objects.filter(post_status='published').order_by('-post_published_date')
#     return render(request, 'blog/index.html', {'posts': posts})

# def home(request):
#     # Main posts list (latest published posts)
#     posts = Post.objects.filter(post_status='published').order_by('-post_published_date')

#     # Top 3 popular posts (based on like count)
#     popular_posts = (
#         Post.objects.filter(post_status='published')
#         .annotate(like_count=Count('postlike'))
#         .order_by('-like_count', '-post_published_date')[:3]
#     )

#     return render(request, 'blog/index.html', {
#         'posts': posts,
#         'popular_posts': popular_posts
#     })

def home(request):
    # Main posts list (latest published posts)
    posts = Post.objects.filter(post_status='published').order_by('-post_published_date')

    # Top 3 popular posts (based on like count)
    popular_posts = (
        Post.objects.filter(post_status='published')
        .annotate(like_count=Count('postlike'))
        .order_by('-like_count', '-post_published_date')[:3]
    )

    # IDs of posts liked by the current user (if logged in)
    liked_post_ids = []
    if request.user.is_authenticated:
        liked_post_ids = list(PostLike.objects.filter(user=request.user).values_list('post_id', flat=True))

    return render(request, 'blog/index.html', {
        'posts': posts,
        'popular_posts': popular_posts,
        'liked_post_ids': liked_post_ids,
    })

# def single_post(request):
#     return render(request, 'blog/single.html')



# def update_coverphoto(request):
#     if request.method == "POST" and request.FILES.get("image"):
#         profile = get_object_or_404(Profile, profile_owner=request.user)
#         profile.profile_coverphoto = request.FILES["image"]  # update only cover photo
#         profile.save()
#         return redirect('profile')  # redirect to profile page
#     return redirect('profile')

# def update_coverphoto(request):
#     if request.method == 'POST':
#         profile, created = Profile.objects.get_or_create(profile_owner=request.user)
#         if 'image' in request.FILES:
#             profile.profile_coverphoto = request.FILES['image']
#             profile.save()
#         return redirect('profile') 

@login_required
def update_coverphoto(request):
    if request.method == 'POST':
        profile, created = Profile.objects.get_or_create(profile_owner=request.user)
        if 'image' in request.FILES:
            profile.profile_coverphoto = request.FILES['image']
            profile.save()
            return JsonResponse({'image_url': profile.profile_coverphoto.url})
        return JsonResponse({'error': 'No image uploaded'}, status=400)

@login_required
def update_profile(request):
    profile, _ = Profile.objects.get_or_create(profile_owner=request.user)

    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('profile')  # or wherever you want to redirect
    else:
        form = ProfileForm(instance=profile)

    return render(request, 'blog/profile_form.html', {'form': form})

# @login_required
# def create_post(request):
#     if request.method == 'POST':
#         create_post_form = PostForm(request.POST)
#         if create_post_form.is_valid():
#             post = create_post_form.save(commit=False)
#             post.post_created_by = request.user
#             post.save()
#             return redirect('post_detail', pk=post.pk)  # or wherever you want to redirect
#     else:
#         create_post_form = PostForm()
#     return render(request, 'blog/create_post.html', {'form': create_post_form})

@login_required
def create_post(request):
    if request.method == 'POST':
        # form = PostForm(request.POST)
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.post_created_by = request.user  # Set the user here
             
            # Set published date if status is changed to 'published'
            if post.post_status == 'published' and not post.post_published_date:
                post.post_published_date = timezone.now()
            post.save()
            return redirect('profile')
    else:
        form = PostForm()
    return render(request, 'blog/create_post.html', {'form': form})

def user_posts(request):
    # Check if the user is authenticated
    if request.user.is_authenticated:
        posts = Post.objects.filter(post_created_by=request.user)
    else:
        posts = Post.objects.none()  # No posts if the user is not authenticated

    return render(request, 'blog/user_posts.html', {'posts': posts})

# def single_post(request, id):
#     post = get_object_or_404(Post, pk=id)
#     return render(request, 'blog/single_post.html', {'post': post})

def single_post(request, id):
    post = get_object_or_404(Post, pk=id)

    # Default: no liked posts
    liked_post_ids = set()

    if request.user.is_authenticated:
        liked_post_ids = set(
            PostLike.objects.filter(user=request.user).values_list("post_id", flat=True)
        )

    return render(request, 'blog/single_post.html', {
        'post': post,
        'liked_post_ids': liked_post_ids,
    })

# @login_required
# def like_post(request):
#     if request.method == "POST":
#         post_id = request.POST.get('post_id')
#         try:
#             post = Post.objects.get(id=post_id)
#         except Post.DoesNotExist:
#             return JsonResponse({'error': 'Post not found'}, status=404)

#         liked, created = PostLike.objects.get_or_create(user=request.user, post=post)

#         if created:
#             post.post_likes += 1
#             post.save()
#             return JsonResponse({'liked': True, 'likes_count': post.post_likes})
#         else:
#             liked.delete()
#             post.post_likes -= 1
#             post.save()
#             return JsonResponse({'liked': False, 'likes_count': post.post_likes})

#     return JsonResponse({'error': 'Invalid request'}, status=400)

@login_required
def like_post(request, post_id):
    if request.method != "POST":
        return JsonResponse({"error": "POST required"}, status=400)

    post = get_object_or_404(Post, id=post_id)
    user = request.user

    liked = PostLike.objects.filter(post=post, user=user).first()
    if liked:
        liked.delete()
        post.post_likes = max(post.post_likes - 1, 0)
        post.save()
        liked_status = False
    else:
        PostLike.objects.create(post=post, user=user)
        post.post_likes += 1
        post.save()
        liked_status = True

    return JsonResponse({
        "liked": liked_status,
        "likes_count": post.post_likes
    })
# def following_posts(request):
#     posts = Post.objects.filter(post_created_by__followers__follower=request.user)

#     if request.user.is_authenticated:
#         # Add a boolean field 'user_liked' to each post
#         liked_subquery = PostLike.objects.filter(post=OuterRef('pk'), user=request.user)
#         posts = posts.annotate(user_liked=Exists(liked_subquery))

#     return render(request, 'blog/following.html', {'posts': posts})

@login_required
def following_posts(request):
    # 1) Get IDs of profiles followed by the user
    following_profile_ids = Follow.objects.filter(follower=request.user).values_list('author_id', flat=True)

    # 2) Get posts from those authors
    posts = Post.objects.filter(post_created_by__profile__id__in=following_profile_ids).order_by('-post_published_date')

    # 3) Get post IDs liked by current user
    liked_post_ids = list(PostLike.objects.filter(user=request.user).values_list('post_id', flat=True))

    return render(request, 'blog/following_posts.html', {
        'posts': posts,
        'liked_post_ids': liked_post_ids,
    })




# def follow_list(request):
#     profiles = Profile.objects.all()
#     return render(request, "blog/follow_table.html", {"profiles": profiles})

@login_required
def all_authors_list(request):
    profiles = Profile.objects.all()

    # get IDs of authors the logged-in user follows
    following_ids = set(
        Follow.objects.filter(follower=request.user).values_list("author_id", flat=True)
    )

    return render(
        request,
        "blog/follow_table.html",
        {"profiles": profiles, "following_ids": following_ids},
    )

@login_required
def follow_list(request):
    # exclude the current user’s profile (profile_owner is FK to User)
    profiles = Profile.objects.exclude(profile_owner=request.user)

    # get IDs of authors the logged-in user follows
    following_ids = set(
        Follow.objects.filter(follower=request.user).values_list("author_id", flat=True)
    )

    return render(
        request,
        "blog/follow_table.html",
        {"profiles": profiles, "following_ids": following_ids},
    )


# @login_required
# def follow_author(request, profile_id):
#     profile = get_object_or_404(Profile, id=profile_id)
#     Follow.objects.get_or_create(follower=request.user, author=profile)
#     return redirect("follow_list")  # or wherever you want to go back

@login_required
def follow_author(request, profile_id):
    author = get_object_or_404(Profile, id=profile_id)
    follow = Follow.objects.filter(follower=request.user, author=author).first()

    if follow:  # already following → unfollow
        follow.delete()
    else:       # not following → follow
        Follow.objects.create(follower=request.user, author=author)

    return redirect("follow_list")   # refresh page after toggle

@login_required
def my_posts(request):
    user_posts = Post.objects.filter(post_created_by=request.user).order_by('-post_created_date')
    return render(request, "blog/my_posts.html", {"user_posts": user_posts})

# @login_required
# def following_posts(request):
#     # Find all profiles the logged-in user follows
#     followed_profiles = Follow.objects.filter(
#         follower=request.user
#     ).values_list("author__profile_owner", flat=True)

#     # Get posts created by those profile owners (Users)
#     posts = Post.objects.filter(
#         post_created_by__in=followed_profiles
#     ).order_by("-post_created_date")

#     return render(request, "blog/following_posts.html", {"posts": posts})

def index(request):
    # Fetch all posts ordered by published date (latest first)
    posts = Post.objects.all().order_by('-post_published_date')

    return render(request, 'blog/index.html', {'posts': posts})

# def most_liked_posts(request):
#     # Annotate each post with like_count and order by it
#     posts = (
#         Post.objects.filter(post_status='published')
#         .annotate(like_count=Count('postlike'))
#         .order_by('-like_count', '-post_published_date')
#     )
#     return render(request, 'blog/most_liked.html', {'posts': posts})

def most_liked_posts(request):
    posts = (
        Post.objects.filter(post_status='published')
        .annotate(like_count=Count('postlike'))
        .order_by('-like_count', '-post_published_date')
    )

    liked_post_ids = set()
    if request.user.is_authenticated:
        liked_post_ids = set(
            PostLike.objects.filter(user=request.user).values_list("post_id", flat=True)
        )

    return render(request, 'blog/most_liked.html', {
        'posts': posts,
        'liked_post_ids': liked_post_ids
    })


# def posts_by_category(request, category_id):
#     category = get_object_or_404(cat, id=category_id)
#     posts = Post.objects.filter(
#         post_category=category,
#         post_status="published"
#     ).order_by('-post_published_date')

#     return render(request, 'blog/posts_by_category.html', {
#         'category': category,
#         'posts': posts,
#     })

def posts_by_category(request, category_id):
    category = get_object_or_404(cat, id=category_id)

    posts = (
        Post.objects.filter(
            post_category=category,
            post_status="published"
        )
        .order_by('-post_published_date')
    )

    # check liked posts (only if user logged in)
    liked_post_ids = set()
    if request.user.is_authenticated:
        liked_post_ids = set(
            PostLike.objects.filter(user=request.user).values_list("post_id", flat=True)
        )

    return render(request, 'blog/posts_by_category.html', {
        'category': category,
        'posts': posts,
        'liked_post_ids': liked_post_ids
    })

# def get_comments(request, post_id):
#     post = Post.objects.get(id=post_id)
#     comments = post.comments.select_related("comment_written_by").all()
#     data = {
#         "comments": [{"user": c.comment_written_by.username, "text": c.comment_data} for c in comments]
#     }
#     return JsonResponse(data)

# @login_required
def get_comments(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    comments = post.comments.select_related("comment_written_by__profile").all()

    data = []
    for c in comments:
        if hasattr(c.comment_written_by, "profile") and c.comment_written_by.profile.profile_photo:
            photo_url = c.comment_written_by.profile.profile_photo.url
        else:
            photo_url = "/static/blog/images/avatar.jpg"

        data.append({
            "user": c.comment_written_by.username,
            "text": c.comment_data,
            "photo": photo_url,
        })

    return JsonResponse({"comments": data})

# @login_required
# def add_comment(request, post_id):
#     if request.method == "POST":
#         body = json.loads(request.body)
#         text = body.get("comment_data")
#         post = Post.objects.get(id=post_id)
#         comment = Comments.objects.create(
#             post=post,
#             comment_written_by=request.user,
#             comment_data=text
#         )
#         return JsonResponse({"user": request.user.username, "text": comment.comment_data})

@login_required
def add_comment(request, post_id):
    if request.method == "POST":
        body = json.loads(request.body)
        text = body.get("comment_data")
        post = get_object_or_404(Post, id=post_id)

        comment = Comments.objects.create(
            post=post,
            comment_written_by=request.user,
            comment_data=text
        )

        # return user photo (or default)
        if hasattr(request.user, "profile") and request.user.profile.profile_photo:
            photo = request.user.profile.profile_photo.url
        else:
            photo = "/static/blog/images/avatar.jpg"

        return JsonResponse({
            "user": request.user.username,
            "text": comment.comment_data,
            "photo": photo,
        })

    return JsonResponse({"error": "Invalid request"}, status=400)