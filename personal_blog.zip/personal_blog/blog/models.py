from django.db import models
from django.contrib.auth.models import User
# from ckeditor.fields import RichTextField
from ckeditor_uploader.fields import RichTextUploadingField
from adminpanel.models import Category as cat

# Create your models here.

# class Profile(models.Model):
#     profile_name = models.CharField(max_length=100, blank=True, null=True)
#     profile_photo = models.ImageField(upload_to='profile_photos/', blank=True, null=True)
#     profile_coverphoto = models.ImageField(upload_to='coverphotos/', blank=True, null=True)
#     # profile_blogid = models.CharField(max_length=50, blank=True, null=True)
#     profile_blogid = models.CharField(max_length=50, unique=True, blank=True, null=True)
#     profile_about = models.TextField(blank=True, null=True)
#     profile_gender = models.CharField(
#         max_length=10,
#         choices=[('Male', 'Male'), ('Female', 'Female')],
#         blank=True, null=True
#     )
#     profile_dob = models.DateField(blank=True, null=True)
#     profile_owner = models.ForeignKey(User, on_delete=models.CASCADE)

#     def __str__(self):
#         return self.profile_name or str(self.id)

# class Profile(models.Model):
#     profile_name = models.CharField(max_length=100, blank=True, null=True)
#     profile_photo = models.ImageField(upload_to='profile_photos/', blank=True, null=True)
#     profile_coverphoto = models.ImageField(upload_to='coverphotos/', blank=True, null=True)
#     profile_blogid = models.CharField(max_length=50, unique=True, blank=True, null=True)
#     profile_about = models.TextField(blank=True, null=True)
#     profile_gender = models.CharField(
#         max_length=10,
#         choices=[('Male', 'Male'), ('Female', 'Female')],
#         blank=True, null=True
#     )
#     profile_dob = models.DateField(blank=True, null=True)
#     profile_owner = models.OneToOneField(
#         User, on_delete=models.CASCADE, related_name='profile'
#     )

#     def __str__(self):
#         return self.profile_name or str(self.id)


class Profile(models.Model):
    profile_name = models.CharField(max_length=100, blank=True, null=True)
    profile_photo = models.ImageField(upload_to='profile_photos/', blank=True, null=True)
    profile_coverphoto = models.ImageField(upload_to='coverphotos/', blank=True, null=True)
    profile_blogid = models.CharField(max_length=50, unique=True, blank=True, null=True)
    profile_about = models.TextField(blank=True, null=True)
    profile_gender = models.CharField(
        max_length=10,
        choices=[('Male', 'Male'), ('Female', 'Female')],
        blank=True, null=True
    )
    profile_dob = models.DateField(blank=True, null=True)

    # 👇 New fields
    profile_work = models.TextField(blank=True, null=True)
    profile_education = models.TextField(blank=True, null=True)
    profile_phone = models.CharField(max_length=20, blank=True, null=True)
    profile_email = models.EmailField(blank=True, null=True)

    profile_owner = models.OneToOneField(
        User, on_delete=models.CASCADE, related_name='profile'
    )

    def __str__(self):
        return self.profile_name or str(self.id)

class Category(models.Model):
    category_name = models.CharField(max_length=100)

    def __str__(self):
        return self.category_name


class Post(models.Model):
    post_created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    post_created_date = models.DateTimeField(auto_now_add=True)
    post_published_date = models.DateTimeField(null=True, blank=True)
    post_status = models.CharField(max_length=20, choices=[('draft', 'Draft'), ('published', 'Published')])
    post_title = models.CharField(max_length=200)
    # post_data = models.TextField()
    # post_data = RichTextField()
    post_data = RichTextUploadingField()
    post_likes = models.PositiveIntegerField(default=0)
    post_category = models.ForeignKey(cat, on_delete=models.SET_NULL, null=True)
    post_main_image = models.ImageField(upload_to='posts/images/', null=True, blank=True)

    def __str__(self):
        return self.post_title


# class Comments(models.Model):
#     comment_data = models.TextField()
#     post = models.ForeignKey(Post, on_delete=models.CASCADE)
#     comment_written_by = models.ForeignKey(User, on_delete=models.CASCADE)

#     def __str__(self):
#         return f"Comment by {self.comment_written_by}"

class Comments(models.Model):
    comment_data = models.TextField()
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name="comments")
    comment_written_by = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return f"Comment by {self.comment_written_by}"


class Work(models.Model):
    work_from = models.DateField()
    work_upto = models.DateField()
    work_position = models.CharField(max_length=100)
    work_firm = models.CharField(max_length=150)
    work_owner = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.work_position


class Education(models.Model):
    education_institution = models.CharField(max_length=150)
    education_course = models.CharField(max_length=150)
    education_batch = models.CharField(max_length=50)
    education_owner = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.education_institution
    
class PostLike(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    liked_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'post')  # Prevent duplicate likes


class Follow(models.Model):
    follower = models.ForeignKey(User, on_delete=models.CASCADE, related_name="follows")
    author = models.ForeignKey("Profile", on_delete=models.CASCADE, related_name="followers")
    followed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("follower", "author")  # prevent duplicate follows

    def __str__(self):
        return f"{self.follower.username} follows {self.author.profile_name}"