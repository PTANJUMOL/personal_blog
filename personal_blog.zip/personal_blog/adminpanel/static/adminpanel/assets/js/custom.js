// static/your_app/js/custom.js

document.addEventListener('DOMContentLoaded', function () {
    const likeButtons = document.querySelectorAll('.like-button');

    likeButtons.forEach(button => {
        button.addEventListener('click', function (e) {
            e.preventDefault();
            const postId = this.dataset.postId;

            // Check if the button has data-authenticated attribute
            const isAuthenticated = this.dataset.authenticated === "true";

            if (!isAuthenticated) {
                alert("Please login to like posts.");
                return;
            }

            fetch("/like/", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded",
                    "X-CSRFToken": getCSRFToken()
                },
                body: `post_id=${postId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.liked !== undefined) {
                    this.classList.toggle('liked');
                    this.innerHTML = `${data.likes_count}`;
                }
            });
        });
    });
});

// Helper to get CSRF token from cookie
function getCSRFToken() {
    let cookieValue = null;
    const name = "csrftoken";
    if (document.cookie && document.cookie !== "") {
        const cookies = document.cookie.split(';');
        for (let cookie of cookies) {
            cookie = cookie.trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
