from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('profile/', views.profile_view, name='profile'),
    path('category/', views.category_view, name='category'),
    path('category/add/', views.add_category, name='category_add'),
    path('category/edit/<int:pk>/', views.edit_category, name='category_edit'),
    path('category/delete/<int:pk>/', views.delete_category, name='category_delete'),
    path('posts/', views.admin_post_list, name='admin_post_list'),
    path('posts/delete/<int:id>/', views.admin_post_delete, name='admin_post_delete'),
    path('posts/toggle-status/<int:id>/', views.admin_post_toggle_status, name='admin_post_toggle_status'),
    
    path('users/', views.users_view, name='users'),
]