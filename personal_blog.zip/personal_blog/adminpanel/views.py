from django.shortcuts import render,redirect, get_object_or_404
from .models import Category
from blog.models import Post
from blog.models import Profile
from .forms import CategoryForm
from django.contrib.auth.decorators import login_required

# Create your views here.
from django.contrib.auth.decorators import user_passes_test
# from django.contrib.auth.decorators import login_required

# Optional: Allow only staff/superuser to access
# def is_admin(user):
#     return user.is_staff or user.is_superuser

# @user_passes_test(is_admin)
def dashboard_view(request):
    return render(request, 'adminpanel/dashboard.html')


# def profile_view(request):
#     user_profile = get_object_or_404(Profile, profile_owner=request.user)
#     return render(request, 'blog/profile.html', {
#         'user_profile': user_profile,
#     })

@login_required(login_url='login')  # Redirects to URL named 'login' if user not authenticated
def profile_view(request):
    # Get the profile for the current user
    user_profile = get_object_or_404(Profile, profile_owner=request.user)

    # Get all posts created by this user
    user_posts = Post.objects.filter(post_created_by=request.user).order_by('-post_created_date')

    return render(request, 'blog/profile.html', {
        'user_profile': user_profile,
        'user_posts': user_posts,
    })



def category_view(request):
    categories = Category.objects.all()
    form = CategoryForm()

    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('category')

    return render(request, 'adminpanel/category_list.html', {'categories': categories, 'form': form})


def users_view(request):
    return render(request, 'adminpanel/users_list.html')

def add_category(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('category_add')
    else:
        form = CategoryForm()
    return render(request, 'adminpanel/add_categories.html', {'form': form})

def edit_category(request, pk):
    category = get_object_or_404(Category, pk=pk)
    if request.method == 'POST':
        form = CategoryForm(request.POST, instance=category)
        if form.is_valid():
            form.save()
            return redirect('category')  # or your list view name
    else:
        form = CategoryForm(instance=category)
    
    return render(request, 'adminpanel/edit_categories.html', {'form': form, 'category': category})

def delete_category(request, pk):
    category = get_object_or_404(Category, pk=pk)
    if request.method == 'POST':
        category.delete()
        return redirect('category')  # Adjust to your categories list view name
    # Optional: confirm page
    return render(request, 'adminpanel/confirm_delete.html', {'category': category})

def admin_post_list(request):
    posts = Post.objects.all().order_by('-post_created_date')
    return render(request, 'adminpanel/post_list.html', {'posts': posts})

def admin_post_delete(request, id):
    post = get_object_or_404(Post, id=id)
    if request.method == "POST":
        post.delete()
        return redirect('admin_post_list')
    return redirect('admin_post_list')

def admin_post_toggle_status(request, id):
    post = get_object_or_404(Post, id=id)
    if post.post_status == 'published':
        post.post_status = 'draft'
    else:
        post.post_status = 'published'
    post.save()
    return redirect('admin_post_list')