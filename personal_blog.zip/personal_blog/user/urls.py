from django.urls import path,include
from user.views import loginpage, logoutpage
from . import views

urlpatterns = [
    path('login/', loginpage, name='login'),
    path('logout/', logoutpage, name='logout'),
    path('register/', views.registerpage, name='register'),
    path('forget/', views.forget_password_view, name='forget'),
]